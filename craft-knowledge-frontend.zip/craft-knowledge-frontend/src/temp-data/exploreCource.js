const data=[
    {
        "name": "Accelerate Tableau CRM with Apps",
        "points": 1600,
        "text": "Learn how out-of-the-box apps can help you go faster with Tableau CRM.",
        "month":3,
        "start":4.8,
        "rating":30780,
        "time":"5 hrs 40 min"
    },
    {
        "name": "Accelerate Tableau CRM with Apps",
        "points": 1600,
        "text": "Learn how out-of-the-box apps can help you go faster with Tableau CRM.",
        "month":3,
        "start":4.8,
        "rating":30780,
        "time":"5 hrs 40 min"
    },
    {
        "name": "Accelerate Tableau CRM with Apps",
        "points": 1600,
        "text": "Learn how out-of-the-box apps can help you go faster with Tableau CRM.",
        "month":3,
        "start":4.8,
        "rating":30780,
        "time":"5 hrs 40 min"
    },
    {
        "name": "Accelerate Tableau CRM with Apps",
        "points": 1600,
        "text": "Learn how out-of-the-box apps can help you go faster with Tableau CRM.",
        "month":3,
        "start":4.8,
        "rating":30780,
        "time":"5 hrs 40 min"
    },
    {
        "name": "Accelerate Tableau CRM with Apps",
        "points": 1600,
        "text": "Learn how out-of-the-box apps can help you go faster with Tableau CRM.",
        "month":3,
        "start":4.8,
        "rating":30780,
        "time":"5 hrs 40 min"
    },
    {
        "name": "Accelerate Tableau CRM with Apps",
        "points": 1600,
        "text": "Learn how out-of-the-box apps can help you go faster with Tableau CRM.",
        "month":3,
        "start":4.8,
        "rating":30780,
        "time":"5 hrs 40 min"
    }
]

export default data;