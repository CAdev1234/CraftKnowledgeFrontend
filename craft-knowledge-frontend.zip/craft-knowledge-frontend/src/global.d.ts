declare module '*.jpg';
declare module '*.svg';
declare module '*.png';